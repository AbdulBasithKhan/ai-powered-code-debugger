import streamlit as st
import requests
import json
import pyperclip

# Streamlit UI Title
st.title("🛠️ AI-Powered Code Debugger")

# Sidebar for settings
st.sidebar.header("Debugger Settings")
language = st.sidebar.selectbox(
    "Select Programming Language",
    ["python", "java", "javascript", "csharp"]
)

# Code input box with session state for clearing
if "code_input" not in st.session_state:
    st.session_state.code_input = ""
code_input = st.text_area("Enter your code:", height=200, value=st.session_state.code_input, placeholder="Paste your code here...")

# Clear button
if st.button("🗑️ Clear Code"):
    st.session_state.code_input = ""
    st.experimental_rerun()  # Refresh the app to apply the clear

# Debug button
if st.button("🔍 Debug Code"):
    if code_input.strip():
        st.info("🔄 Sending code for debugging...")

        # API Call with loading spinner and verify=False to avoid SSL issues
        with st.spinner("Analyzing code..."):
            api_url = "http://127.0.0.1:5000/debug"
            payload = json.dumps({"language": language, "code": code_input})
            headers = {"Content-Type": "application/json"}

            try:
                response = requests.post(api_url, data=payload, headers=headers, timeout=30, verify=False)
                result = response.json()

                # Display results
                if response.status_code == 200:
                    if result["status"] == "bug":
                        st.error("❌ Bugs Found!")
                        buggy_lines = set()
                        
                        for bug in result["bugs"]:
                            buggy_lines.add(bug['line'])
                            st.markdown(
                                f"🚨 **Bug:** {bug['message']} (Line {bug['line']}) - *Confidence: {round(bug['confidence'] * 100)}%*"
                            )
                        
                        # Highlight buggy lines
                        highlighted_code = ""
                        for i, line in enumerate(code_input.split('\n'), start=1):
                            if i in buggy_lines:
                                highlighted_code += f"🔴 {line}\n"
                            else:
                                highlighted_code += f"  {line}\n"
                        
                        # Display Original vs Fixed Code
                        col1, col2 = st.columns(2)
                        with col1:
                            st.subheader("🔍 Original Code")
                            st.code(highlighted_code, language=language)
                        with col2:
                            st.subheader("✅ Suggested Fix")
                            if "fixed" in result and result["fixed"] and not result["fixed"].startswith("Error"):
                                st.code(result["fixed"], language=language)
                                # Display explanation if available
                                if "explanations" in result and result["explanations"] and result["explanations"][0]:
                                    st.markdown(f"**Explanation:** {result['explanations'][0]}")
                                # Copy Fix Button
                                if st.button("📋 Copy Fix"):
                                    pyperclip.copy(result["fixed"])
                                    st.success("✅ Code copied to clipboard!")
                            else:
                                st.warning("⚠️ No valid fix available. Check the logs or retry later.")

                    elif result["status"] == "clean":
                        st.success(f"🎉 {result['message']}")
                        st.code(result["original"], language=language)
                else:
                    st.error(f"⚠️ Error: {result.get('error', 'Unknown issue')}")
                    if st.button("🔄 Retry"):
                        st.experimental_rerun()

            except requests.exceptions.RequestException as e:
                st.error(f"🚨 API Error: {e}")
                if st.button("🔄 Retry"):
                    st.experimental_rerun()
    else:
        st.warning("⚠️ Please enter some code to debug.")

# Run the Streamlit app using:
# streamlit run streamlit.py