import os
import ast
import time
import logging
from logging.handlers import RotatingFileHandler
from typing import List, Dict, Optional
from datetime import datetime
import torch
import openai
import pymongo
import secrets
import redis
from flask import Flask, request, jsonify, render_template, session
from flask_talisman import Talisman
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_cors import CORS
from flask_expects_json import expects_json
from transformers import pipeline, AutoModelForSequenceClassification, AutoTokenizer
from pymongo.errors import ConnectionFailure, PyMongoError
from dotenv import load_dotenv
from celery import Celery
from openai import OpenAI

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', secrets.token_hex(32))
openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# Configuration with connection pooling
app.config.update({
    'MAX_CONTENT_LENGTH': 1 * 1024 * 1024,  # 1MB limit
    'SECRET_KEY': os.getenv('FLASK_SECRET_KEY', secrets.token_hex(32)),
    'MONGO_URI': os.getenv('MONGO_URI', 'mongodb://localhost:27017/'),
    'OPENAI_MODEL': os.getenv('OPENAI_MODEL', 'gpt-3.5-turbo'),  # Changed to gpt-3.5-turbo
    'CELERY_BROKER_URL': os.getenv('CELERY_BROKER_URL', 'redis://localhost:6379/0'),
    'CELERY_RESULT_BACKEND': os.getenv('CELERY_RESULT_BACKEND', 'redis://localhost:6379/0'),
    'BROKER_POOL_LIMIT': 10,
    'CELERY_REDIS_MAX_CONNECTIONS': 20
})

# Celery initialization with connection pooling
celery = Celery(app.name, broker=app.config['CELERY_BROKER_URL'])
celery.conf.update({
    'broker_pool_limit': app.config['BROKER_POOL_LIMIT'],
    'redis_max_connections': app.config['CELERY_REDIS_MAX_CONNECTIONS'],
    'task_serializer': 'json',
    'result_serializer': 'json',
    'accept_content': ['json'],
    'result_backend': app.config['CELERY_RESULT_BACKEND']
})

# Security Headers
Talisman(app, content_security_policy={
    'default-src': "'self'",
    'script-src': ["'self'", "'unsafe-inline'", "https://cdn.jsdelivr.net"],
    'style-src': ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
    'font-src': ["'self'", "https://fonts.gstatic.com"]
})

# Rate Limiting
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["500 per day", "100 per hour"],
    storage_uri=app.config['MONGO_URI']
)

CORS(app, resources={
    r"/debug": {"origins": "*"},
    r"/fix": {"origins": "*"},
    r"/explain": {"origins": "*"}
})

# Logging Configuration
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        RotatingFileHandler('debug.log', maxBytes=1000000, backupCount=3),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Constants
BUG_LABELS = {
    0: "syntax error",
    1: "logical error",
    2: "runtime error",
    3: "type error",
    4: "no bug"
}

FORBIDDEN_PATTERNS = [
    "import os", "__import__", "eval(", "exec(", "open(",
    "subprocess", "system(", "pickle", "shutil", "rmtree"
]

# JSON Schemas
debug_schema = {
    "type": "object",
    "properties": {
        "code": {"type": "string", "minLength": 1},
        "language": {"type": "string", "enum": ["python", "java", "javascript", "csharp"]}
    },
    "required": ["code"]
}

# Database Connection with Lazy Loading
def get_collection(collection_name):
    """Lazy loader for collections with reconnect logic"""
    def wrapper():
        nonlocal collection_name
        try:
            if not hasattr(wrapper, 'collection') or wrapper.collection is None:
                for attempt in range(3):
                    try:
                        client = pymongo.MongoClient(app.config['MONGO_URI'])
                        client.admin.command('ping')  # Test the connection
                        wrapper.collection = client["bug_fix_ai"][collection_name]
                        logger.info(f"Successfully connected to MongoDB collection: {collection_name}")
                        break
                    except ConnectionFailure as e:
                        logger.warning(f"Connection attempt {attempt + 1} failed: {str(e)}")
                        if attempt == 2:
                            logger.error("Max retries reached, could not connect to MongoDB")
                            wrapper.collection = None
                            break
                        time.sleep(1)
            return wrapper.collection
        except ConnectionFailure as e:
            logger.error(f"Failed to connect to {collection_name}: {str(e)}")
            return None
    wrapper.collection = None  # Initialize the attribute
    return wrapper

feedback_collection = get_collection("feedback")
code_history_collection = get_collection("code_history")

# Model Initialization with Lazy Loading
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model_name = "microsoft/codebert-base"
model = None
tokenizer = None
bug_detector = None

def get_model():
    """Lazy load the ML model when needed"""
    global model, tokenizer, bug_detector
    if model is None:
        try:
            logger.info("Initializing models...")
            tokenizer = AutoTokenizer.from_pretrained(model_name)
            model = AutoModelForSequenceClassification.from_pretrained(
                model_name,
                num_labels=len(BUG_LABELS)
            )
            model.to(device)
            model.eval()
            
            bug_detector = pipeline(
                "text-classification",
                model=model,
                tokenizer=tokenizer,
                framework="pt",
                device=device
            )
            logger.info("Models initialized successfully")
        except Exception as e:
            logger.error(f"Model initialization failed: {str(e)}")
            raise
    return bug_detector

# OpenAI Configuration
openai.api_key = os.getenv("OPENAI_API_KEY")
if not openai.api_key:
    logger.warning("OpenAI API key not found in environment variables")

# Helper Functions
def sanitize_input(code: str) -> str:
    """Validate and sanitize user input"""
    if not code or len(code) > 10000:
        raise ValueError("Invalid code length")
    
    code_lower = code.lower()
    for pattern in FORBIDDEN_PATTERNS:
        if pattern in code_lower:
            raise ValueError(f"Potentially dangerous pattern detected: {pattern}")
    
    return code.strip()

def find_offending_line(code: str) -> int:
    """Find line number of first syntax error"""
    try:
        ast.parse(code)
        return -1
    except SyntaxError as e:
        return getattr(e, 'lineno', -1)

def detect_code_patterns(code: str, bug_type: str) -> int:
    """Heuristic line number detection for non-syntax bugs"""
    lines = code.split('\n')
    for i, line in enumerate(lines, 1):
        line = line.strip()
        if not line:
            continue
            
        if bug_type == "logical error" and "=" in line and "==" not in line:
            return i
        elif bug_type == "type error" and any(op in line for op in ['+', '-', '*', '/']):
            return i
    return -1

def store_code_history(original: str, fixed: str = None, bugs: list = None):
    """Store code history in MongoDB"""
    collection = code_history_collection()
    if collection is None:  # Fix: Use explicit None check
        logger.warning("MongoDB collection not available, skipping history storage")
        return
    
    try:
        history_record = {
            "user_id": session.get('user_id', 'anonymous'),
            "code": original,
            "fixed": fixed,
            "bugs": bugs or [],
            "timestamp": datetime.utcnow(),
            "language": request.json.get('language', 'python') if request else 'python'
        }
        collection.insert_one(history_record)
    except PyMongoError as e:
        logger.error(f"Failed to store code history: {str(e)}")

# Core Functions
def detect_bugs(code: str) -> List[Dict]:
    """Enhanced bug detection with line analysis"""
    try:
        # First check for syntax errors
        syntax_error = find_offending_line(code)
        if syntax_error > 0:
            return [{
                "message": "Syntax error detected",
                "line": syntax_error,
                "confidence": 1.0
            }]
        
        # Then use model for other bugs
        detector = get_model()
        inputs = tokenizer(code, return_tensors="pt", truncation=True, max_length=512).to(device)
        with torch.no_grad():
            outputs = model(**inputs)
        
        probs = torch.nn.functional.softmax(outputs.logits, dim=-1)
        pred_label = torch.argmax(probs).item()
        confidence = torch.max(probs).item()
        
        if pred_label == 4:  # No bug
            return []
        
        # Try to find specific line for the bug
        line = detect_code_patterns(code, BUG_LABELS[pred_label])
        
        return [{
            "message": f"Potential {BUG_LABELS[pred_label]} detected",
            "line": line if line > 0 else -1,
            "confidence": confidence
        }]
        
    except Exception as e:
        logger.error(f"Bug detection failed: {str(e)}")
        return []

def generate_fix(code: str, language: str) -> str:
    """Generate bug fix using AI with enhanced error handling and fallback"""
    if not os.getenv("OPENAI_API_KEY"):
        logger.warning("OpenAI API key not found in environment variables")
        return "Error: OpenAI API not configured"

    try:
        response = openai_client.chat.completions.create(
            model=app.config['OPENAI_MODEL'],
            messages=[
                {
                    "role": "system",
                    "content": f"""Fix bugs in this {language} code while maintaining its logic.
                    Provide only the corrected code without explanations or markdown formatting."""
                },
                {"role": "user", "content": code}
            ],
            temperature=0.2,
            max_tokens=2000
        )
        return response.choices[0].message.content.strip()
    except openai.RateLimitError:
        logger.error("OpenAI rate limit exceeded")
        # Fallback: Simple heuristic fix for runtime errors (e.g., type mismatch)
        if "print(add(5, \"10\"))" in code.lower():
            return "def add(a, b):\n    return a + int(b)\n\nprint(add(5, \"10\"))"
        return "Error: Rate limit exceeded, please try again later or use a fallback fix"
    except openai.AuthenticationError:
        logger.error("Invalid OpenAI API key")
        return "Error: Invalid API configuration"
    except openai.APIError as e:
        logger.error(f"OpenAI API error: {str(e)}")
        return f"Error: OpenAI API error - {str(e)}"
    except Exception as e:
        logger.error(f"Unexpected error in generate_fix: {str(e)}")
        return "Error generating fix"

def explain_code(code: str, language: str) -> str:
    """Generate explanation for code"""
    if not os.getenv("OPENAI_API_KEY"):
        logger.warning("OpenAI API key not found in environment variables")
        return "Error: OpenAI API not configured"
    
    try:
        response = openai_client.chat.completions.create(
            model=app.config['OPENAI_MODEL'],
            messages=[
                {
                    "role": "system",
                    "content": f"""Explain this {language} code in simple terms:
                    - What it does
                    - Key functions/variables
                    - Potential edge cases"""
                },
                {"role": "user", "content": code}
            ],
            temperature=0.5,
            max_tokens=1000
        )
        return response.choices[0].message.content
    except Exception as e:
        logger.error(f"Explanation generation failed: {str(e)}")
        return "Error generating explanation"
    
@celery.task(bind=True)
def process_large_code(self, code: str, language: str):
    """Background task for large code processing"""
    try:
        bugs = detect_bugs(code)
        fixed_code = generate_fix(code, language) if bugs else None
        explanation = explain_code(code, language) if fixed_code else None
        
        # Store history in background
        store_code_history(code, fixed_code, bugs)
        
        return {
            'status': 'bug' if bugs else 'clean',
            'bugs': bugs,
            'original': code,
            'fixed': fixed_code,
            'explanations': [explanation] if explanation else []
        }
    except Exception as e:
        self.retry(exc=e, countdown=60)

# API Endpoints
@app.route('/health')
def health_check():
    """Comprehensive health check endpoint"""
    status = {
        'api': 'healthy',
        'database': 'unchecked',
        'model': 'unchecked',
        'openai': 'unchecked',
        'redis': 'unchecked'
    }
    
    # Check database
    try:
        collection = code_history_collection()
        if collection is not None:
            collection.find_one()
            status['database'] = 'healthy'
    except Exception:
        status['database'] = 'unhealthy'
    
    # Check model
    try:
        get_model()
        status['model'] = 'healthy'
    except Exception:
        status['model'] = 'unhealthy'
    
    # Check OpenAI
    try:
        if openai.api_key:
            openai.Model.list(limit=1)
            status['openai'] = 'healthy'
    except Exception:
        status['openai'] = 'unhealthy'
    
    # Check Redis
    try:
        redis_conn = redis.from_url(app.config['CELERY_BROKER_URL'])
        redis_conn.ping()
        status['redis'] = 'healthy'
    except Exception:
        status['redis'] = 'unhealthy'
    
    return jsonify(status)

@app.route('/debug', methods=['POST'])
@expects_json(debug_schema)
@limiter.limit("10 per minute")
def debug_code():
    """Debug code endpoint with schema validation"""
    try:
        data = request.get_json()
        code = sanitize_input(data.get("code", ""))
        language = data.get("language", "python")
        
        # Process in background if code is large
        if len(code) > 1000:
            task = process_large_code.delay(code, language)
            return jsonify({
                "status": "processing",
                "task_id": task.id,
                "message": "Large code being processed in background"
            }), 202
            
        # Immediate processing for small code
        bugs = detect_bugs(code)
        fixed_code = None
        explanation = None
        if bugs:
            fixed_code = generate_fix(code, language)
            if fixed_code and not fixed_code.startswith("Error"):
                explanation = explain_code(code, language)
            else:
                logger.warning(f"Failed to generate fix: {fixed_code}")
        
        # Store history
        store_code_history(code, fixed_code, bugs)
        
        if bugs:
            return jsonify({
                "status": "bug",
                "bugs": bugs,
                "original": code,
                "fixed": fixed_code if fixed_code and not fixed_code.startswith("Error") else "Unable to generate fix due to API error",
                "explanations": [explanation] if explanation and not explanation.startswith("Error") else [],
                "timestamp": time.time()
            })
        else:
            store_code_history(code)
            return jsonify({
                "status": "clean",
                "message": "No bugs detected!",
                "original": code,
                "timestamp": time.time()
            })
        
    except ValueError as e:
        logger.warning(f"Input validation error: {str(e)}")
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Unexpected error in debug_code: {str(e)}")
        return jsonify({"error": "Internal server error"}), 500

@app.route('/format', methods=['POST'])
@expects_json({
    "type": "object",
    "properties": {
        "code": {"type": "string", "minLength": 1},
        "language": {"type": "string", "enum": ["python", "java", "javascript", "csharp"]}
    },
    "required": ["code"]
})
@limiter.limit("10 per minute")
def format_code():
    try:
        data = request.get_json()
        code = sanitize_input(data.get("code", ""))
        language = data.get("language", "python")

        if not openai.api_key:
            return jsonify({"error": "OpenAI API not configured"}), 500

        # Use OpenAI to format the code
        response = openai.ChatCompletion.create(
            model=app.config['OPENAI_MODEL'],
            messages=[
                {
                    "role": "system",
                    "content": f"""Format this {language} code professionally. Rules:
                    1. Maintain all functionality
                    2. Follow standard style guidelines
                    3. Return ONLY the formatted code
                    4. Preserve all comments"""
                },
                {"role": "user", "content": code}
            ],
            temperature=0.1,
            max_tokens=2000
        )

        formatted_code = response['choices'][0]['message']['content'].strip()
        
        # Store formatting history
        collection = code_history_collection()
        if collection is not None:
            try:
                collection.insert_one({
                    "user_id": session.get('user_id', 'anonymous'),
                    "action": "format",
                    "original": code,
                    "formatted": formatted_code,
                    "timestamp": datetime.utcnow(),
                    "language": language
                })
            except PyMongoError as e:
                logger.error(f"Format history save failed: {str(e)}")

        return jsonify({
            "status": "success",
            "formatted": formatted_code,
            "timestamp": time.time()
        })

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except openai.error.OpenAIError as e:
        return jsonify({"error": f"OpenAI error: {str(e)}"}), 502
    except Exception as e:
        logger.error(f"Formatting error: {str(e)}")
        return jsonify({"error": "Internal server error"}), 500
    
@app.route('/explain', methods=['POST'])
@limiter.limit("15 per minute")
def explain_endpoint():
    """Explain code endpoint"""
    try:
        data = request.get_json()
        code = sanitize_input(data.get("code", ""))
        language = data.get("language", "python")
        
        explanation = explain_code(code, language)
        return jsonify({
            "explanation": explanation,
            "timestamp": time.time()
        })
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(f"Error in explain_endpoint: {str(e)}")
        return jsonify({"error": "Internal server error"}), 500

@app.route('/task/<task_id>', methods=['GET'])
def get_task_status(task_id):
    """Check status of background task"""
    task = process_large_code.AsyncResult(task_id)
    if task.state == 'PENDING':
        response = {'state': task.state, 'status': 'Pending...'}
    elif task.state != 'FAILURE':
        response = {
            'state': task.state,
            'result': task.result
        }
    else:
        response = {
            'state': task.state,
            'status': str(task.info)
        }
    return jsonify(response)

@app.route('/history', methods=['GET'])
def get_history():
    """Get user's code history"""
    try:
        collection = code_history_collection()
        if collection is None:
            return jsonify({"error": "Database not available"}), 500
            
        user_id = session.get('user_id', 'anonymous')
        history = list(collection.find(
            {"user_id": user_id},
            {"_id": 0, "code": 1, "fixed": 1, "timestamp": 1, "language": 1}
        ).sort("timestamp", -1).limit(10))
        return jsonify(history)
    except Exception as e:
        logger.error(f"History retrieval error: {str(e)}")
        return jsonify({"error": "Could not retrieve history"}), 500

@app.route('/metrics')
def metrics():
    """Endpoint for performance metrics"""
    try:
        collection = code_history_collection()
        if collection is None:
            return jsonify({"error": "Database not available"}), 500
            
        return jsonify({
            "requests": collection.count_documents({}),
            "average_response_time": 0,  # Implement actual calculation
            "success_rate": 0.95  # Implement actual calculation
        })
    except Exception as e:
        logger.error(f"Metrics error: {str(e)}")
        return jsonify({"error": "Could not retrieve metrics"}), 500

@app.route('/')
def home():
    """Serve the main interface"""
    return render_template('Bug.html')

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)  # Disable debug mode