import requests
import time
import json
import unittest
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

class BackendTest(unittest.TestCase):
    BASE_URL = "http://127.0.0.1:5000"
    TIMEOUT = 60  # Increased timeout to 60 seconds
    
    def setUp(self):
        # Configure retry strategy
        self.session = requests.Session()
        retries = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[500, 502, 503, 504]
        )
        self.session.mount('http://', HTTPAdapter(max_retries=retries))
        
        # Wait for backend to be ready
        self.wait_for_backend()

    def wait_for_backend(self):
        """Wait until backend is responsive"""
        max_attempts = 10
        for attempt in range(max_attempts):
            try:
                response = self.session.get(
                    f"{self.BASE_URL}/health",
                    timeout=5
                )
                if response.status_code == 200:
                    return
            except Exception:
                pass
            time.sleep(3)
        raise Exception("Backend did not become ready")

    def test_health_check(self):
        """Test the health check endpoint"""
        print("\nTesting health check endpoint...")
        try:
            start = time.time()
            response = requests.get(
                f"{self.BASE_URL}/health",
                timeout=self.TIMEOUT
            )
            elapsed = time.time() - start
            
            print(f"Response ({elapsed:.2f}s): {response.status_code}")
            print(json.dumps(response.json(), indent=2))
            
            self.assertEqual(response.status_code, 200)
            health_data = response.json()
            self.assertIn("api", health_data)
            self.assertEqual(health_data["api"], "healthy")
            
            print("✅ Health check passed")
            return True
            
        except Exception as e:
            print(f"❌ Health check failed: {str(e)}")
            self.fail(f"Health check failed: {str(e)}")
            return False

    def test_debug_endpoint(self):
        """Test the debug endpoint with various cases"""
        print("\nTesting debug endpoint...")
        test_results = []
        
        for case_name, test_data in self.test_cases.items():
            print(f"\nRunning test case: {case_name}")
            try:
                start = time.time()
                response = requests.post(
                    f"{self.BASE_URL}/debug",
                    json={
                        "code": test_data["code"],
                        "language": test_data["language"]
                    },
                    timeout=self.TIMEOUT
                )
                elapsed = time.time() - start
                
                print(f"Response ({elapsed:.2f}s): {response.status_code}")
                print(json.dumps(response.json(), indent=2))
                
                self.assertEqual(response.status_code, 200)
                response_data = response.json()
                self.assertIn("status", response_data)
                
                if test_data["expected_status"] == "processing":
                    self.assertIn("task_id", response_data)
                else:
                    self.assertEqual(response_data["status"], test_data["expected_status"])
                
                test_results.append(True)
                print(f"✅ {case_name} passed")
                
            except Exception as e:
                test_results.append(False)
                print(f"❌ {case_name} failed: {str(e)}")
                continue
        
        self.assertTrue(all(test_results), "Some debug tests failed")
        return all(test_results)

    def test_task_status(self):
        """Test background task status endpoint"""
        print("\nTesting task status endpoint...")
        
        # First submit a large code processing task
        large_code = self.test_cases["large_code"]["code"]
        try:
            response = requests.post(
                f"{self.BASE_URL}/debug",
                json={
                    "code": large_code,
                    "language": "python"
                },
                timeout=self.TIMEOUT
            )
            self.assertEqual(response.status_code, 202)
            task_id = response.json()["task_id"]
            
            # Now check task status
            max_checks = 5
            for i in range(max_checks):
                time.sleep(2)  # Wait for task to process
                response = requests.get(
                    f"{self.BASE_URL}/task/{task_id}",
                    timeout=self.TIMEOUT
                )
                task_data = response.json()
                
                print(f"Task check {i+1}/{max_checks}: {task_data['state']}")
                
                if task_data['state'] == 'SUCCESS':
                    print("✅ Task completed successfully")
                    print(json.dumps(task_data['result'], indent=2))
                    return True
                elif task_data['state'] == 'FAILURE':
                    print(f"❌ Task failed: {task_data.get('status', 'Unknown error')}")
                    self.fail("Background task failed")
                    return False
            
            self.fail("Task did not complete in expected time")
            return False
            
        except Exception as e:
            print(f"❌ Task status test failed: {str(e)}")
            self.fail(f"Task status test failed: {str(e)}")
            return False

def run_tests():
    """Run all tests and print summary"""
    print("🚀 Starting backend tests...\n")
    test_suite = unittest.TestLoader().loadTestsFromTestCase(BackendTest)
    test_runner = unittest.TextTestRunner(verbosity=2)
    result = test_runner.run(test_suite)
    
    print("\n📊 Test Summary:")
    print(f"Total tests: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    
    if result.wasSuccessful():
        print("\n🎉 All tests passed successfully!")
        return True
    else:
        print("\n❌ Some tests failed")
        return False

if __name__ == "__main__":
    run_tests()