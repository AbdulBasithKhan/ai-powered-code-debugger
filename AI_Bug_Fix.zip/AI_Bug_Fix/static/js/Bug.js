document.addEventListener('DOMContentLoaded', () => {
    const darkModeToggle = document.getElementById('dark-mode');
    const body = document.body;

    // Apply saved Dark Mode setting
    if (localStorage.getItem('darkMode') === 'true') {
        darkModeToggle.checked = true;
        body.classList.add('dark-mode');
    }

    // Dark mode toggle
    darkModeToggle.addEventListener('change', () => {
        body.classList.toggle('dark-mode', darkModeToggle.checked);
        localStorage.setItem('darkMode', darkModeToggle.checked);
    });

    // Tab switching functionality
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            document.querySelectorAll('.tab-content').forEach(content => {
                content.style.display = 'none';
            });
            document.getElementById(btn.dataset.tab).style.display = 'block';
        });
    });

    // Code Formatting
    document.getElementById('format-btn').addEventListener('click', async () => {
        const codeTextarea = document.getElementById('code');
        try {
            const response = await fetch('/format', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code: codeTextarea.value })
            });

            if (!response.ok) throw new Error(await response.text());

            const { formatted } = await response.json();
            codeTextarea.value = formatted;
        } catch (error) {
            console.error('Formatting error:', error);
        }
    });

    // Example Code Button
    document.getElementById('example-btn').addEventListener('click', () => {
        const examples = {
            python: `def calculate_average(numbers):\n    total = sum(numbers)\n    return total / len(numbers)\n\n# Intentional bug - no handling of empty list`,
            javascript: `function getUserName(user) {\n    return user.name;\n}\n\n// Intentional bug - no null check`
        };
        const language = document.getElementById('language').value;
        document.getElementById('code').value = examples[language] || examples.python;
    });

    // Debug Form Submission
    document.getElementById('debug-form').addEventListener('submit', async (event) => {
        event.preventDefault();
        console.log("Debug button clicked");
        const form = event.target;
        const output = document.getElementById('output');
        const submitBtn = form.querySelector('button[type="submit"]');

        submitBtn.disabled = true;
        output.innerHTML = `
            <div class="analyzing">
                <span class="spinner"></span>
                Analyzing code...
            </div>
        `;

        try {
            const response = await fetch('http://127.0.0.1:5000/debug', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    language: form.language.value,
                    code: form.code.value
                })
            });

            if (!response.ok) {
                const err = await response.json();
                throw new Error(err.error || `HTTP ${response.status}`);
            }

            const data = await response.json();

            output.innerHTML = data.status === "bug"
                ? `
                    ${data.bugs.map(bug => `
                        <div class="error">
                            🚨 ${bug.message}
                            <small>Line ${bug.line} (${Math.round(bug.confidence * 100)}% confidence)</small>
                        </div>
                    `).join('')}
                    <div class="code-compare">
                        <div><h3>Original:</h3><pre>${escapeHtml(data.original)}</pre></div>
                        <div><h3>Suggested Fix:</h3><pre class="suggestions">${escapeHtml(data.fixed)}</pre></div>
                    </div>
                    <button class="copy-btn" data-code="${encodeURIComponent(data.fixed)}">📋 Copy Fix</button>
                `
                : `
                    <div class="success">
                        ✅ ${data.message}
                        <pre>${escapeHtml(data.original)}</pre>
                    </div>
                `;

        } catch (error) {
            output.innerHTML = `<div class="error">⛔ ${error.message}<small>Check console for details</small></div>`;
            console.error("Debug Error:", error);
        } finally {
            submitBtn.disabled = false;
        }
    });
});

// HTML Escape Function
const escapeHtml = unsafe => unsafe.replace(/[&<>"]+/g, m => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'
}[m]));

// Copy Suggested Fix
document.addEventListener('click', e => {
    if (e.target.classList.contains('copy-btn')) {
        navigator.clipboard.writeText(decodeURIComponent(e.target.dataset.code));
        e.target.textContent = "✓ Copied!";
        setTimeout(() => e.target.textContent = "📋 Copy Fix", 2000);
    }
});
